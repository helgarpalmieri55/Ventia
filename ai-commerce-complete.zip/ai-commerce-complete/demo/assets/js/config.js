window.APP_CONFIG = {
  brandName: 'AI Commerce',
  brandShort: 'AIC',
  country: 'Colombia',
  locale: 'es-CO',
  currency: 'COP',
  apiBaseUrl: 'https://api.example.com/v1',
  useMocks: true,
  whatsappNumber: '573001234567',
  features: {
    aiAssistant: true,
    whatsapp: true,
    analytics: true,
    finance: true
  }
};
