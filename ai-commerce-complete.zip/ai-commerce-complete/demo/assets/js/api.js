(function(){
  const cfg = window.APP_CONFIG;
  const sleep = (ms=180)=>new Promise(r=>setTimeout(r,ms));
  async function request(path, options={}){
    const res = await fetch(`${cfg.apiBaseUrl}${path}`, {
      headers:{'Content-Type':'application/json', ...(options.headers||{})},
      ...options
    });
    if(!res.ok) throw new Error(`API ${res.status}`);
    return res.status===204 ? null : res.json();
  }
  window.API = {
    async dashboard(){ if(cfg.useMocks){await sleep(); return MOCK_DATA.dashboard;} return request('/dashboard'); },
    async conversations(){ if(cfg.useMocks){await sleep(); return MOCK_DATA.conversations;} return request('/conversations'); },
    async orders(){ if(cfg.useMocks){await sleep(); return MOCK_DATA.orders;} return request('/orders'); },
    async products(){ if(cfg.useMocks){await sleep(); return MOCK_DATA.products;} return request('/products'); },
    async customers(){ if(cfg.useMocks){await sleep(); return MOCK_DATA.customers;} return request('/customers'); },
    async sendMessage(conversationId, text){ if(cfg.useMocks){await sleep(250); return {ok:true,id:Date.now(),conversationId,text};} return request(`/conversations/${conversationId}/messages`,{method:'POST',body:JSON.stringify({text})}); },
    async createOrder(payload){ if(cfg.useMocks){await sleep(350); return {ok:true,id:'#10'+Math.floor(Math.random()*900+100),...payload};} return request('/orders',{method:'POST',body:JSON.stringify(payload)}); },
    async saveProduct(payload){ if(cfg.useMocks){await sleep(300); return {ok:true,id:Date.now(),...payload};} return request('/products',{method:'POST',body:JSON.stringify(payload)}); },
    async aiCommand(prompt){ if(cfg.useMocks){await sleep(500); return {answer:`Encontré una respuesta demo para: “${prompt}”. Conecta /ai/command para usar tu agente real.`};} return request('/ai/command',{method:'POST',body:JSON.stringify({prompt})}); }
  };
})();
