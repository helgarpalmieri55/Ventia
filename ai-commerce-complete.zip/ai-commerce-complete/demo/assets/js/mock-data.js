window.MOCK_DATA = {
  dashboard: {
    kpis: [
      {label:'Ventas (COP)', value:'$12.450.000', delta:'+18,6%', tone:'purple'},
      {label:'Pedidos', value:'236', delta:'+15,3%', tone:'blue'},
      {label:'Conversaciones', value:'412', delta:'+22,1%', tone:'cyan'},
      {label:'Resolución IA', value:'91%', delta:'+6 pp', tone:'green'}
    ],
    alerts: [
      {title:'35 pedidos por despachar', detail:'Valor: $2.980.000 COP', action:'Ver pedidos', route:'orders', icon:'bag'},
      {title:'8 productos con stock bajo', detail:'Podrías perder ventas', action:'Ver productos', route:'products', icon:'box'},
      {title:'12 conversaciones escaladas', detail:'Requieren atención', action:'Ir a conversaciones', route:'conversations', icon:'chat'}
    ],
    activity: [
      {title:'Nueva orden #10325', meta:'Bogotá, Cundinamarca', amount:'$220.000 COP', when:'Hace 1 min', type:'order'},
      {title:'Pago aprobado #10324', meta:'Medellín, Antioquia', amount:'$145.000 COP', when:'Hace 2 min', type:'payment'},
      {title:'Nueva conversación', meta:'Asesoría de producto', amount:'', when:'Hace 3 min', type:'chat'},
      {title:'Pedido despachado #10323', meta:'Cali, Valle del Cauca', amount:'$198.000 COP', when:'Hace 5 min', type:'shipping'}
    ],
    topProducts: [
      {name:'Camiseta Oversize', units:482},
      {name:'Jean Clásico', units:367},
      {name:'Hoodie Premium', units:298}
    ]
  },
  conversations: [
    {id:1,name:'María Fernanda López',channel:'WhatsApp',time:'10:24',preview:'¿Tienen la camiseta oversize en talla M?',status:'IA atendiendo',statusTone:'green',location:'Bogotá, Cundinamarca',phone:'+57 320 456 7890',email:'maria.lopez@example.com',confidence:96,product:'Camiseta Oversize Blanca',price:'$89.900 COP',stock:'18 unidades',intent:'Consulta de producto y envío',messages:[
      {from:'customer',text:'Hola, ¿tienen la camiseta oversize en talla M?',time:'10:21'},
      {from:'ai',text:'¡Hola María Fernanda! Sí, tenemos la Camiseta Oversize Blanca en talla M y disponibilidad inmediata. ¿Te gustaría que te comparta detalles del envío?',time:'10:21'},
      {from:'customer',text:'¿Cuánto tarda el envío a Bogotá?',time:'10:22'},
      {from:'ai',text:'Para Bogotá, el envío estándar tarda de 1 a 2 días hábiles y tiene un costo de $8.900 COP. También tenemos envío express el mismo día por $14.900 COP.',time:'10:22'},
      {from:'customer',text:'Perfecto, ¿qué medios de pago tienen?',time:'10:23'},
      {from:'ai',text:'Aceptamos tarjetas débito y crédito, PSE, Nequi, Daviplata y contra entrega en ciudades seleccionadas. ¿Quieres que te ayude a crear el pedido?',time:'10:23'}
    ]},
    {id:2,name:'Juan David Restrepo',channel:'Instagram',time:'09:58',preview:'¿Cuánto tarda el envío a Medellín?',status:'Pendiente de decisión',statusTone:'orange',location:'Medellín, Antioquia',confidence:88,product:'Jean Clásico Azul',price:'$149.900 COP',stock:'15 unidades',intent:'Envío',messages:[
      {from:'customer',text:'¿Cuánto tarda el envío a Medellín?',time:'09:56'},
      {from:'ai',text:'Normalmente de 1 a 2 días hábiles. Si compras antes de las 2 PM podemos despachar hoy.',time:'09:57'}
    ]},
    {id:3,name:'Valentina Gómez',channel:'WhatsApp',time:'09:41',preview:'¿Puedo pagar contra entrega?',status:'IA atendiendo',statusTone:'green',location:'Barranquilla, Atlántico',confidence:94,product:'Gorra Dad Hat Beige',price:'$69.900 COP',stock:'25 unidades',intent:'Medios de pago',messages:[
      {from:'customer',text:'¿Puedo pagar contra entrega?',time:'09:40'},
      {from:'ai',text:'Sí. En Barranquilla tenemos contra entrega disponible para este producto.',time:'09:41'}
    ]},
    {id:4,name:'Andrés Camacho',channel:'Instagram',time:'09:15',preview:'Necesito ayuda con mi pedido #10234',status:'Necesita humano',statusTone:'red',location:'Cali, Valle del Cauca',confidence:62,product:'Tenis Urbanos White',price:'$209.900 COP',stock:'0 unidades',intent:'Reclamo / pedido',messages:[
      {from:'customer',text:'Necesito ayuda con mi pedido #10234, llegó incompleto.',time:'09:14'},
      {from:'ai',text:'Puedo ayudarte a revisar el estado. Por tratarse de una novedad con el contenido del pedido, voy a escalarlo a un asesor.',time:'09:15'}
    ]}
  ],
  orders: [
    {id:'#10325',customer:'Laura Martínez',city:'Bogotá',total:'$189.900',payment:'Pagado',status:'Por despachar',date:'Hoy 10:32'},
    {id:'#10324',customer:'José Ramírez',city:'Medellín',total:'$349.800',payment:'Contra entrega',status:'Preparando',date:'Hoy 10:18'},
    {id:'#10323',customer:'Camila Rodríguez',city:'Cali',total:'$89.900',payment:'Pagado',status:'Enviado',date:'Hoy 09:52'},
    {id:'#10322',customer:'Daniela Gómez',city:'Barranquilla',total:'$269.900',payment:'Pagado',status:'Entregado',date:'Ayer 17:46'},
    {id:'#10321',customer:'Santiago Pérez',city:'Pereira',total:'$119.800',payment:'PSE',status:'Por confirmar',date:'Ayer 16:30'}
  ],
  products: [
    {id:1,name:'Camiseta Oversize Blanca',sku:'CAM-OV-BLA',category:'Moda > Camisetas',stock:48,price:89900,status:'Publicado',image:'assets/img/mockups/product-main.png'},
    {id:2,name:'Jean Clásico Azul',sku:'JEA-CLA-AZU',category:'Moda > Jeans',stock:15,price:149900,status:'Publicado',image:'assets/img/mockups/product-2.png'},
    {id:3,name:'Hoodie Premium Negro',sku:'HOD-PRE-NEG',category:'Moda > Hoodies',stock:8,price:179900,status:'Publicado',image:'assets/img/mockups/product-3.png'},
    {id:4,name:'Gorra Dad Hat Beige',sku:'GOR-DAD-BEI',category:'Accesorios > Gorras',stock:25,price:69900,status:'Publicado',image:'assets/img/mockups/product-4.png'},
    {id:5,name:'Tenis Urbanos White',sku:'TEN-URB-WHI',category:'Calzado > Tenis',stock:0,price:209900,status:'Publicado',image:'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80'},
    {id:6,name:'Bolso Tote Arena',sku:'BOL-TOT-ARE',category:'Accesorios > Bolsos',stock:64,price:129900,status:'Borrador',image:'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=300&q=80'}
  ],
  customers: [
    {name:'María Fernanda López',location:'Bogotá',orders:6,total:'$1.240.000',segment:'VIP',last:'Hoy'},
    {name:'Juan David Restrepo',location:'Medellín',orders:3,total:'$682.000',segment:'Frecuente',last:'Hoy'},
    {name:'Valentina Gómez',location:'Barranquilla',orders:2,total:'$299.800',segment:'Nuevo',last:'Hoy'},
    {name:'Daniela Usuga',location:'Cali',orders:8,total:'$1.920.000',segment:'VIP',last:'Ayer'},
    {name:'Santiago Morales',location:'Pereira',orders:4,total:'$735.000',segment:'Frecuente',last:'Ayer'}
  ]
};
