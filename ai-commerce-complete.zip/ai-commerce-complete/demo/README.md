# AI Commerce UI — mockup-accurate build

This is the navigable frontend build aligned to the approved mockup direction.

## Visual system

- Poppins typography
- custom outline SVG icon set
- geometric gradient brand mark
- exact light admin shell, spacing, borders, radii and purple AI treatment
- dashboard, conversations, products and store builder redesigned against the mockup references
- storefront Vitrina, Catálogo and Marca presets
- local concept imagery extracted from the approved mockups for closer visual parity

## Admin routes

- `index.html#/dashboard`
- `index.html#/ai`
- `index.html#/conversations`
- `index.html#/orders`
- `index.html#/products`
- `index.html#/customers`
- `index.html#/store`
- `index.html#/analytics`
- `index.html#/finance`
- `index.html#/settings`

## Public pages

- `storefront.html?preset=vitrina`
- `storefront.html?preset=catalogo`
- `storefront.html?preset=marca`
- `product.html?id=1`
- `checkout.html`

## Run locally

```bash
python3 -m http.server 8080
```

or on Windows run `serve.bat`.

This demo folder uses `mock-data.js`. Use the separate production package for real API integration.
