# Backend integration contract

The frontend is intentionally framework-free and can be served as static files. Admin data access is centralized in `assets/js/api.js`.

## Turn mocks off

Edit `assets/js/config.js`:

```js
window.APP_CONFIG = {
  apiBaseUrl: 'https://your-api.example.com/v1',
  useMocks: false
};
```

## Expected admin endpoints

- `GET /dashboard`
- `GET /conversations`
- `POST /conversations/:id/messages`
- `GET /orders`
- `POST /orders`
- `GET /products`
- `POST /products`
- `GET /customers`
- `POST /ai/command`

### Example conversation object

```json
{
  "id": 1,
  "name": "María Fernanda López",
  "channel": "WhatsApp",
  "time": "10:24",
  "preview": "¿Tienen talla M?",
  "status": "IA atendiendo",
  "statusTone": "green",
  "location": "Bogotá, Cundinamarca",
  "phone": "+57 ...",
  "confidence": 96,
  "product": "Camiseta Oversize Blanca",
  "price": "$89.900 COP",
  "stock": "18 unidades",
  "intent": "Consulta de producto y envío",
  "messages": [
    {"from": "customer", "text": "...", "time": "10:21"}
  ]
}
```

### AI command

Request:

```json
{"prompt":"¿Por qué vendimos menos esta semana?"}
```

Response:

```json
{"answer":"..."}
```

## Suggested public/storefront endpoints

- `GET /public/stores/:slug`
- `GET /public/stores/:slug/products`
- `GET /public/stores/:slug/products/:productId`
- `GET /public/stores/:slug/categories`
- `POST /public/stores/:slug/cart/quote`
- `POST /public/stores/:slug/orders`
- `GET /public/stores/:slug/shipping/options?department=&city=`
- `GET /public/stores/:slug/payment-methods`
- `POST /public/stores/:slug/assistant/message`

## Authentication

Add your access token in `assets/js/api.js` inside `request()`:

```js
headers: {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${token}`
}
```

For multi-tenant operation, derive the current merchant/store from the authenticated session or subdomain rather than trusting a tenant ID supplied by the browser.

## Real-time events

The current UI can receive WebSocket or Server-Sent Events without changing the layout. Useful events:

- `conversation.message.created`
- `conversation.escalated`
- `order.created`
- `order.status.changed`
- `payment.approved`
- `inventory.low_stock`
