window.APP_CONFIG = {
  brandName: 'AI Commerce',
  brandShort: 'AIC',
  country: 'Colombia',
  locale: 'es-CO',
  currency: 'COP',
  apiBaseUrl: '/api/v1',
  useMocks: false,
  storeSlug: 'your-store-slug',
  authTokenStorageKey: 'aic_access_token',
  whatsappNumber: '',
  features: {
    aiAssistant: true,
    whatsapp: true,
    analytics: true,
    finance: true
  }
};
