(function(){
  const cfg=window.APP_CONFIG;
  function token(){try{return localStorage.getItem(cfg.authTokenStorageKey)||''}catch(_){return ''}}
  async function request(path,options={}){
    const headers={Accept:'application/json',...(options.body?{'Content-Type':'application/json'}:{}),...(options.headers||{})};
    const t=token(); if(t)headers.Authorization=`Bearer ${t}`;
    const controller=new AbortController(); const timeout=setTimeout(()=>controller.abort(),20000);
    try{
      const res=await fetch(`${cfg.apiBaseUrl}${path}`,{credentials:'include',...options,headers,signal:options.signal||controller.signal});
      if(res.status===401){window.dispatchEvent(new CustomEvent('auth:unauthorized'));throw new Error('UNAUTHORIZED')}
      if(!res.ok){let detail='';try{detail=(await res.json()).message||''}catch(_){detail=await res.text().catch(()=> '')}throw new Error(detail||`API ${res.status}`)}
      if(res.status===204)return null;
      const type=res.headers.get('content-type')||'';return type.includes('application/json')?res.json():res.text();
    }finally{clearTimeout(timeout)}
  }
  const json=(method,body)=>({method,body:JSON.stringify(body)});
  window.API={
    request,
    dashboard:()=>request('/dashboard'),
    conversations:(query='')=>request(`/conversations${query?`?${query}`:''}`),
    conversation:id=>request(`/conversations/${encodeURIComponent(id)}`),
    sendMessage:(id,text)=>request(`/conversations/${encodeURIComponent(id)}/messages`,json('POST',{text})),
    orders:(query='')=>request(`/orders${query?`?${query}`:''}`),
    createOrder:payload=>request('/orders',json('POST',payload)),
    updateOrder:(id,payload)=>request(`/orders/${encodeURIComponent(id)}`,json('PATCH',payload)),
    products:(query='')=>request(`/products${query?`?${query}`:''}`),
    saveProduct:payload=>request('/products',json('POST',payload)),
    updateProduct:(id,payload)=>request(`/products/${encodeURIComponent(id)}`,json('PATCH',payload)),
    customers:(query='')=>request(`/customers${query?`?${query}`:''}`),
    aiCommand:prompt=>request('/ai/command',json('POST',{prompt})),
    publicStore:slug=>request(`/public/stores/${encodeURIComponent(slug)}`),
    publicProducts:(slug,query='')=>request(`/public/stores/${encodeURIComponent(slug)}/products${query?`?${query}`:''}`),
    publicProduct:(slug,id)=>request(`/public/stores/${encodeURIComponent(slug)}/products/${encodeURIComponent(id)}`),
    categories:slug=>request(`/public/stores/${encodeURIComponent(slug)}/categories`),
    shippingOptions:(slug,params={})=>request(`/public/stores/${encodeURIComponent(slug)}/shipping/options?${new URLSearchParams(params)}`),
    paymentMethods:slug=>request(`/public/stores/${encodeURIComponent(slug)}/payment-methods`),
    createPublicOrder:(slug,payload)=>request(`/public/stores/${encodeURIComponent(slug)}/orders`,json('POST',payload)),
    assistantMessage:(slug,message,context={})=>request(`/public/stores/${encodeURIComponent(slug)}/assistant/message`,json('POST',{message,context}))
  };
})();
