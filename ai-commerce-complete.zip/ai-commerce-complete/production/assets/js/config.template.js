window.APP_CONFIG = {
  brandName: '${BRAND_NAME}',
  brandShort: '${BRAND_SHORT}',
  country: 'Colombia',
  locale: 'es-CO',
  currency: 'COP',
  apiBaseUrl: '${API_BASE_URL}',
  useMocks: false,
  storeSlug: '${STORE_SLUG}',
  authTokenStorageKey: 'aic_access_token',
  whatsappNumber: '${WHATSAPP_NUMBER}',
  features: { aiAssistant:true, whatsapp:true, analytics:true, finance:true }
};
