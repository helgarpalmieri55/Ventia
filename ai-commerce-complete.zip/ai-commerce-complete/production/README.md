# AI Commerce UI

Complete static frontend prototype for an AI-centered e-commerce platform focused initially on Colombia.

## Included screens

### Admin
- Inicio / dashboard
- AI Assistant
- Conversations / WhatsApp + Instagram + human handoff
- Orders
- Products + AI-assisted creation
- Customers
- Store builder with Vitrina, Catálogo and Marca presets
- Analytics
- Finance
- Settings

### Public storefront
- `storefront.html` — Vitrina preset
- `storefront.html?preset=catalogo` — Catálogo preset
- `product.html?id=1` — Product detail
- `checkout.html` — 3-step Colombian checkout

## Run locally

No build process is required.

```bash
python3 -m http.server 8080
```

Then open:

```text
http://localhost:8080/index.html
```

On Windows you can also double-click `serve.bat`.

## Rename the product

Edit `assets/js/config.js`:

```js
brandName: 'Your final name'
```

## Connect the backend

1. Set `apiBaseUrl` in `assets/js/config.js`.
2. Change `useMocks` to `false`.
3. Map the real routes in `assets/js/api.js`.
4. See `BACKEND-INTEGRATION.md`.

## Technology

- HTML5
- CSS3
- Vanilla JavaScript
- Fetch API
- No npm packages
- No framework
- Responsive desktop/mobile layouts
