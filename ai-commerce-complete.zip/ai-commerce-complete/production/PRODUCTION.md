# Production frontend

This folder is the production version of the mockup-accurate frontend.

## What changed from the demo build

- `mock-data.js` is removed.
- `useMocks` is always `false`.
- Admin views call the real API through `assets/js/api.js`.
- Storefront/product pages call `GET /public/stores/:slug/products`.
- Store assistant calls `POST /public/stores/:slug/assistant/message`.
- Checkout calls `POST /public/stores/:slug/orders`.
- API errors render a controlled UI state rather than a blank screen.
- Docker + Nginx deployment files are included.

## Required backend endpoints

### Admin

- `GET /api/v1/dashboard`
- `GET /api/v1/conversations`
- `GET /api/v1/conversations/:id`
- `POST /api/v1/conversations/:id/messages`
- `GET /api/v1/orders`
- `POST /api/v1/orders`
- `PATCH /api/v1/orders/:id`
- `GET /api/v1/products`
- `POST /api/v1/products`
- `PATCH /api/v1/products/:id`
- `GET /api/v1/customers`
- `POST /api/v1/ai/command`

### Public store

- `GET /api/v1/public/stores/:slug`
- `GET /api/v1/public/stores/:slug/products`
- `GET /api/v1/public/stores/:slug/products/:id`
- `GET /api/v1/public/stores/:slug/categories`
- `GET /api/v1/public/stores/:slug/shipping/options`
- `GET /api/v1/public/stores/:slug/payment-methods`
- `POST /api/v1/public/stores/:slug/orders`
- `POST /api/v1/public/stores/:slug/assistant/message`

The product list may return either an array or `{ "items": [...] }` / `{ "products": [...] }`.

## Authentication

`api.js` supports both cookie-based sessions (`credentials: include`) and bearer tokens. If a token exists in `localStorage` under `aic_access_token`, it is sent as:

```http
Authorization: Bearer <token>
```

For a multi-tenant admin, determine the tenant on the server from the authenticated session/token. Do not trust a merchant ID supplied by the browser.

## Docker deployment

```bash
docker build -t ai-commerce-web .
docker run --rm -p 8080:80 \
  -e API_BASE_URL=https://api.example.com/v1 \
  -e BRAND_NAME="Your Brand" \
  -e BRAND_SHORT="YB" \
  -e STORE_SLUG="my-store" \
  ai-commerce-web
```

The startup script generates `assets/js/config.js` from environment variables.

## Static hosting

If deploying to S3, Azure Static Web Apps, Cloudflare Pages, Netlify, etc., generate `assets/js/config.js` during deployment from `config.template.js`, or edit `config.js` directly.

## Visual assets

The prototype currently references some Unsplash images by URL. Replace these with merchant/backend media URLs in production. The UI itself does not require those example URLs once the API supplies product images.
