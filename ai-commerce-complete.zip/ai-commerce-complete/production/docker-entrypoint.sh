#!/bin/sh
set -eu
: "${API_BASE_URL:=/api/v1}"
: "${BRAND_NAME:=AI Commerce}"
: "${BRAND_SHORT:=AIC}"
: "${STORE_SLUG:=your-store-slug}"
: "${WHATSAPP_NUMBER:=}"
envsubst '${API_BASE_URL} ${BRAND_NAME} ${BRAND_SHORT} ${STORE_SLUG} ${WHATSAPP_NUMBER}' \
  < /usr/share/nginx/html/assets/js/config.template.js \
  > /usr/share/nginx/html/assets/js/config.js
exec nginx -g 'daemon off;'
